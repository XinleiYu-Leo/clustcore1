package com.example.sendchat;

import androidx.appcompat.app.AppCompatActivity;


import android.app.ProgressDialog;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.sendchat.app.AppController;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    private ArrayList<String> listItems = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    private Button send_txt;
    private ListView chat_box;
    private EditText txt_chat;
    private String url = "http://coms-309-vb-6.misc.iastate.edu/";
    private String urlGetTest = "https://api.androidhive.info/volley/person_object.json";
    private String add_List;
    private Button open_chat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send_txt = findViewById(R.id.send_txt);
        txt_chat = findViewById(R.id.txt_chat);
        chat_box = findViewById(R.id.chat_box);
        open_chat = findViewById(R.id.open_chat);

        send_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSTR();
            }
        });

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems);
        chat_box.setAdapter(adapter);

        open_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSTR();
            }
        });
    }

    private void getSTR(){

        String tag_json = "json_obj_req";
        final ProgressDialog pD = new ProgressDialog(this);
        pD.setMessage("Here it come...");
        pD.show();

        JsonObjectRequest Get = new JsonObjectRequest(Request.Method.GET, urlGetTest, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                pD.hide();
                add_List = response.toString();
                listItems.add(add_List);
                adapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.toString();
            }
        });

        AppController.getInstance().addToRequestQueue(Get, tag_json);
    }



    private void sendSTR()
    {

        String send_Chat = txt_chat.toString();
        String tag_json_obj = "json_obj_req";

        Map<String, String> params = new HashMap<>();
        //params.put(//User, //Username);
        params.put("Message", send_Chat);

        JSONObject jsonObject = new JSONObject(params);


        JsonObjectRequest Send =  new JsonObjectRequest(Request.Method.POST, url, jsonObject, new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response)
            {
                Toast.makeText(getApplicationContext(), "response", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        });


        AppController.getInstance().addToRequestQueue(Send, tag_json_obj);

    }}

