package com.example.userlogin;

import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edt_name;
    private Button btn_confirm;
    private TextView User_credentials;
    private EditText edt_pass;
    private EditText edt_conPass;
    private boolean capital = false;
    private boolean lowercase = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_name = findViewById(R.id.edt_name);
        btn_confirm = findViewById(R.id.btn_confirm);
        User_credentials = findViewById(R.id.User_credentials);
        edt_pass = findViewById(R.id.edt_pass);
        edt_conPass = findViewById(R.id.edt_conPass);

        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pass_Confirm();
            }
        });
    }
     public void pass_Confirm() {
         String user = edt_name.getText().toString().trim();
         String password = edt_pass.getText().toString().trim();
         String conPass = edt_conPass.getText().toString().trim();
            if(user.isEmpty()) {
                Toast.makeText(this, "Username field is empty", Toast.LENGTH_SHORT).show();
            }
            if (!password.equals(conPass)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            }
            if(password.length() < 10)
            {
                Toast.makeText(this, "Password is less than 10 characters", Toast.LENGTH_SHORT).show();
            }
         for(int i = 0; i <= password.length()-1; i++){
                if(Character.isUpperCase(password.charAt(i))){
                    capital = true;
                }
                if(Character.isLowerCase(password.charAt(i))) {
                    lowercase = true;
                }
            }
            if(!capital){
                Toast.makeText(this, "no capital letters found", Toast.LENGTH_SHORT).show();
            }
            if(!lowercase){
                Toast.makeText(this, "no lowercase letters found", Toast.LENGTH_SHORT).show();
            }
            RequestQueue queue = Volley.newRequestQueue(this);
     }
}


