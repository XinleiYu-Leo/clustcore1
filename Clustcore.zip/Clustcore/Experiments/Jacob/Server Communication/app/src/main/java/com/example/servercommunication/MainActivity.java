package com.example.servercommunication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;

import org.json.JSONObject;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.servercommunication.app.AppController;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button buttonSendSTR;
    private String url = "http://coms-309-vb-6.misc.iastate.edu/";
    private EditText txt_Chat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonSendSTR = findViewById(R.id.buttonSendSTR);
        txt_Chat = findViewById(R.id.txt_Chat) ;

        buttonSendSTR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendSTR();
            }
        });
    }

    private void sendSTR()
    {
        String send_Chat = txt_Chat.toString();
        String tag_json_obj = "json_obj_req";



        JsonObjectRequest Send =  new JsonObjectRequest(Request.Method.POST, url, null, new Response.Listener<JSONObject>(){
                @Override
            public void onResponse(JSONObject response)
                {

                    Toast.makeText(getApplicationContext(), "response", Toast.LENGTH_SHORT).show();
                }
        }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            VolleyLog.d(TAG, "Error: " + error.getMessage());
                        }
                    });

        @Override
        protected Map<String,String> getParams()
    {
        Map<String, String> params = new HashMap<>();
        //params.put(//User, //Username);
        params.put("Message", send_Chat);
        //params.put(//Date&Time, //date);

        return params;
    }

        AppController.getInstance().addToRequestQueue(Send, tag_json_obj);

}}
