package com.example.servercommunication.net_utils;

public class Const {
    public static final String URL_Server_Comm = "http://coms-309-vb-6.misc.iastate.edu/";
}
