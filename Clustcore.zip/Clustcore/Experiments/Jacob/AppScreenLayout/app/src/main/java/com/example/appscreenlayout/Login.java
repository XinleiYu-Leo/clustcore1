package com.example.appscreenlayout;

import android.content.Intent;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.example.appscreenlayout.app.AppController;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    private Button but_back;
    private Button but_reset;
    private Button but_login;
    private EditText txt_pass;
    private EditText txt_user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        but_back = findViewById(R.id.but_back);
        but_login = findViewById(R.id.but_login);
        but_reset = findViewById(R.id.but_reset);
        txt_pass = findViewById(R.id.txt_pass);
        txt_user = findViewById(R.id.txt_user);

        but_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_Main();
            }
        });

        but_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginRequest();
            }
        });

        but_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openReset();
            }
        });
    }

    private void LoginRequest() {
        String password = txt_pass.getText().toString();
        String username = txt_user.getText().toString();

        String url = String.format("http://coms-309-vb-6.misc.iastate.edu:8080/login?username=%1$s&password=%2$s", username, password);

        String tag_json_obj = "json_obj_req";

        StringRequest Send =  new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                JSONObject resp = null;
                try {
                    resp = new JSONObject(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if(getStatus(resp))
                {
                    Intent a = new Intent(getBaseContext(), HubWorld.class);
                    startActivity(a);
                }
            }
        },  new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }});




        AppController.getInstance().addToRequestQueue(Send, tag_json_obj);
    }

    public void back_Main(){
        Intent a = new Intent(this, MainActivity.class);
        startActivity(a);
    }


    public void openReset(){
        Intent a = new Intent(this, ResetPassword.class);
        startActivity(a);
    }

    public boolean getStatus(JSONObject response)
    {
        return response.optBoolean("status");
    }





}
