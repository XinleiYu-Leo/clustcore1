package com.example.appscreenlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HubWorld extends AppCompatActivity {

    private Button btn;
    private Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hub_world);

        btn = (findViewById(R.id.but_shop));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });

        btn2 = (findViewById(R.id.but_friends));
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity1();
            }
        });
    }

    public void openActivity(){
        Intent a = new Intent(getBaseContext(), Shop.class);
        startActivity(a);
    }

    public void openActivity1(){
        Intent a = new Intent(getBaseContext(), FriendsList.class);
        startActivity(a);
    }
}
