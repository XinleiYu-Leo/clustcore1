package com.example.clustercore.net_utils;

public class Const {
    // store the URLs for network calls. Visit the URLs to look at the data present in the URL.
    // public static final String URL_JSON_OBJECT = "httpls://api.androidhive.info/volley/person_object.json";
}
