package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.SurfaceHolder;

import androidx.constraintlayout.solver.widgets.Rectangle;

public class Loop extends Thread{

    private int fps = 30;
    private double avgfps;
    private SurfaceHolder holder;
    private Game game;
    private boolean running;
    public static Canvas canvas;
    public Rectangle rect;
    public int healthval = 1440;



    public Loop(SurfaceHolder surfaceHolder, Game game){

        super();
        this.holder = surfaceHolder;
        this.game = game;

    }

    @Override
    public void run() {
        long start;
        long time;
        long wait;
        long total = 0;
        int frame  = 0;
        long target = 1000/fps;


        while (running) {
            start = System.nanoTime();
            canvas = null;

            try {
                canvas = this.holder.lockCanvas();
                synchronized (holder){
                    //Main Loop Code

                    this.game.update();
                    this.game.draw(canvas);
                    canvas.drawColor(Color.WHITE);
                    Paint paint = new Paint();
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(game.xpos,game.ypos-1000,30, paint);

                    Rect rect = new Rect(200,200,400,400);
                    canvas.drawRect(rect,paint);

                    if (200 < game.xpos & game.xpos < 400 & game.ypos-1000 < 400 & game.ypos-1000 > 200){
                        canvas.drawColor(Color.RED);
                        healthval -= 10;
                    }

                    Paint paint1 = new Paint();
                    paint1.setStyle(Paint.Style.FILL);
                    paint1.setColor(Color.GREEN);
                    Rect health = new Rect(0, 2500,healthval,2960);
                    canvas.drawRect(health,paint1);



                }
            }

            catch (Exception a) {
                a.printStackTrace();
            }

            finally {
                if (canvas != null){
                    try{
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception a){
                        a.printStackTrace();
                    }
                }
            }

            time = (System.nanoTime() - start) / 1000000;
            wait = target - time;

            try {
                this.sleep(wait);
            }
            catch (Exception a){
                a.printStackTrace();
            }

            total += System.nanoTime() - start;
            frame++;
            if (frame == fps) {
                avgfps = 1000 / ((total / frame) / 1000000);
                frame = 0;
                total = 0;
                System.out.println(avgfps);
            }

        }

    }

    public void setRunning (boolean isRunning){
        running = isRunning;
    }

}
