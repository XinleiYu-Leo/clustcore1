package com.example.myapplication;

import android.content.Context;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class Game extends SurfaceView implements SurfaceHolder.Callback {

    private Loop loop;
    public int xpos;
    public int ypos;

    public Game (Context context) {
        super(context);

        getHolder().addCallback(this);

        loop = new Loop(getHolder(), this);

        setFocusable(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder){
        loop.setRunning(true);
        loop.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h){

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        boolean retry = true;
        while (retry) {
            try {
                loop.setRunning(false);
                loop.join();
            }
            catch (InterruptedException a){
                a.printStackTrace();
            }
            retry = false;
        }
    }

    @Override public boolean onTouchEvent (MotionEvent event){
        switch(event.getAction()){
            case MotionEvent.ACTION_MOVE:
                xpos = (int) event.getX();
                ypos = (int) event.getY();
        }

        return true;
    }

    public void update() {

    }
}
