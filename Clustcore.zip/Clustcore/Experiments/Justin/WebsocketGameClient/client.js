/* connection configuration */
var server_port = 9002;
var server_host = 'localhost';
var delta_threshold = 0.001; /* minimum velocity to consider sending an update for */

/* key bindings */
var input_map = {
    ArrowLeft: 'left',
    ArrowRight: 'right',
    ArrowUp: 'up',
    ArrowDown: 'down',
};

function translate_input(k) {
    if (k in input_map) return input_map[k];
}

/* client state */
var server_sock     = null;
var last_frame_time = null;

var input_state = {
    left: false,
    right: false,
    up: false,
    down: false,
};

var player = {
    x: 100,  /* current position vector */
    y: 100,
    dx: 0,   /* current velocity vector */
    dy: 0,
    ax: 1000, /* movement acceleration */
    ay: 1000,
    mdx: 200, /* maximum velocity */
    mdy: 200,
    decel: 1.6, /* deceleration factor */
};

/* game loop, render function */
function render_frame(time) {
    /* compute time delta */
    if (!last_frame_time) {
        last_frame_time = time;
    }

    var dt = (time - last_frame_time) / 1000.0;
    last_frame_time = time;

    /* animate character on dt */
    player.x += player.dx * dt;
    player.y += player.dy * dt;

    /* change player velocity on acceleration and inputs */
    if (input_state.left) {
            player.dx = Math.max(player.dx - player.ax * dt, -player.mdx);
    }

    if (input_state.right) {
            player.dx = Math.min(player.dx + player.ax * dt, player.mdx);
    }

    if (input_state.up) {
            player.dy = Math.max(player.dy - player.ay * dt, -player.mdy);
    }

    if (input_state.down) {
            player.dy = Math.min(player.dy + player.ay * dt, player.mdy);
    }

    /* decelerate player if no movement for each axis */
    if (!(input_state.left ^ input_state.right)) {
        player.dx /= player.decel;
    }

    if (!(input_state.up ^ input_state.down)) {
        player.dy /= player.decel;
    }

    /* update the DOM with the new player location */
    $('.player').css({
        left: player.x,
        top: player.y,
    });

    /* if player is moving, send server the updated location */
    if (Math.abs(player.dx) > delta_threshold || Math.abs(player.dy) > delta_threshold) {
        if (server_sock) server_sock.send(JSON.stringify(player));
    }

    /* request the next frame */
    window.requestAnimationFrame(render_frame);
};

$(document).ready(function() {
    /* initialize websocket connection */
    server_sock = new WebSocket('ws://' + server_host + ':' + server_port);

    server_sock.onerror = function(err) {
        console.log('WebSocket connection error: ' + err);
        server_sock = null;
        $('.connerror').css({display: 'block'});
    };

    /* initialize keyboard handlers */
    $('*').keydown(function(evt) {
        evt.key = translate_input(evt.key);
        if (evt.key in input_state) {
            input_state[evt.key] = true;
        }
    });

    $('*').keyup(function(evt) {
        evt.key = translate_input(evt.key);
        if (evt.key in input_state) {
            input_state[evt.key] = false;
        }
    });

    /* start game loop */
    window.requestAnimationFrame(render_frame);
});
