#include <iostream>
#include <string>

#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/server.hpp>

#define PORT 9002

/* bring in bullshit types */
using websocketpp::lib::placeholders::_1;
using websocketpp::lib::placeholders::_2;
using websocketpp::lib::bind;

typedef websocketpp::server<websocketpp::config::asio> server;
typedef server::message_ptr message_ptr;

static void message_handler(server* s, websocketpp::connection_hdl hdl, message_ptr msg) {
    std::cout << "Server received message HDL: " << hdl.lock().get() << " , payload: " << msg->get_payload() << "\n";

    try {
        s->send(hdl, msg->get_payload(), msg->get_opcode());
    } catch (websocketpp::exception const& e) {
        std::cout << "Server couldn't respond: " << e.what() << "\n";
    }
}

int main(int argc, char** argv) {
    server test_server;

    try {
        std::cout << "Starting server..\n";

        test_server.set_access_channels(websocketpp::log::alevel::all);
        test_server.clear_access_channels(websocketpp::log::alevel::frame_payload);

        test_server.init_asio();
        test_server.set_message_handler(bind(&message_handler, &test_server, ::_1, ::_2));

        test_server.listen(PORT);
        test_server.start_accept();

        std::cout << "Waiting for connections..\n";

        test_server.run();
    } catch (websocketpp::exception const& e) {
        std::cerr << "Server error: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
