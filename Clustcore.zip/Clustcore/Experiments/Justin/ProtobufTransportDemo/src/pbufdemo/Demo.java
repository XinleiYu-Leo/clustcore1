package pbufdemo;

import java.io.IOException;
import java.net.*;

import pbufdemo.Clustercore;

public class Demo {
	private final static int PORT = 3300;
	
	public static void main(String[] args) {
		/* Prompt user for execution mode */
		
		try {
			System.out.println("Please enter a mode to start [c => client, s => server]");
			int mode = System.in.read();
			
			if (mode == 'c') {
				executeClient();
			} else {
				executeServer();
			}
			
			System.out.println("Terminating cleanly.");
		} catch (IOException e) {
			System.out.println("Unexpected I/O error: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	/*
	 * Run the demo server.
	 */
	private static void executeServer() {
		System.out.println("Starting protobuf transport server.");
		
		try {
			ServerSocket sock = new ServerSocket(PORT);
			
			/* Wait for clients and read messages */
			while (true) {
				System.out.println("Waiting for client.");
				Socket client = sock.accept();
				System.out.println("Accepted client: " + client.getRemoteSocketAddress().toString());
				
				/* Parse a message from the socket stream */
				Clustercore.Echo msg_input = Clustercore.Echo.parseDelimitedFrom(client.getInputStream());
				
				System.out.println("Received a message: " + msg_input.getContent());
				
				/* Send it back where it came from */
				msg_input.writeDelimitedTo(client.getOutputStream());
				System.out.println("Sent back to client.");
				
				/* Clean up connection socket. */
				System.out.println("Closing connection with client.");
				client.close();
			}
		} catch (IOException e) {
			System.out.println("I/O error in server: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	private static void executeClient() {
		System.out.println("Starting protobuf transport client.");
		
		try {
			Socket sock = new Socket("localhost", PORT);
			
			/* Build an echo message to send. */
			Clustercore.Echo echo_msg = Clustercore.Echo.newBuilder().setContent("Hello protobuf world!").build();			
			
			/* Send it over. */
			System.out.println("Sending echo message: " + echo_msg.getContent());
			echo_msg.writeDelimitedTo(sock.getOutputStream());
			
			/* Wait for a response */
			System.out.println("Waiting for server response.");
			Clustercore.Echo msg_input = Clustercore.Echo.parseDelimitedFrom(sock.getInputStream());
			System.out.println("Received an echo message: " + msg_input.getContent());
			
			/* clean up sockets */
			System.out.println("Closing connection with server.");
			sock.close();
		} catch (IOException e) {
			System.out.println("I/O error in client: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
