var host = 'localhost:8080';

$(document).ready(function() {
    console.log('Initializing client.. remote host ' + host);

    $('#login_submit').click(function() {
        jQuery.get('http://' + host + '/login', {
            username: $('#login_user_input').val(),
            password: $('#login_pw_input').val(),
        }, function (res) {
            if (res.status) {
                $('#login_result').css('color', '#0f0');
            } else {
                $('#login_result').css('color', '#ff0');
            }

            $('#login_result').html(res.message);
        });
    });

    $('#reg_submit').click(function() {
        jQuery.get('http://' + host + '/register', {
            username: $('#reg_user_input').val(),
            email: $('#reg_email_input').val(),
            password: $('#reg_pw_input').val(),
        }, function (res) {
            if (res.status) {
                $('#reg_result').css('color', '#0f0');
            } else {
                $('#reg_result').css('color', '#ff0');
            }

            $('#reg_result').html(res.message);
        });
    });
});
