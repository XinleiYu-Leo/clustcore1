package vb6.clustercore;

import org.springframework.data.domain.*;
import org.springframework.data.repository.*;

public interface UserRepository extends CrudRepository<User, Integer> {
}
