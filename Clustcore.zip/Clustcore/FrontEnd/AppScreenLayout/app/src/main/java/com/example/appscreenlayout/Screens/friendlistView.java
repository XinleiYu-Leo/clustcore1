package com.example.appscreenlayout.Screens;

public interface friendlistView {
    /**
     * friendlist only contains protected and private classes
     */
}
