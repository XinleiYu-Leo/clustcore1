package com.example.appscreenlayout.Screens;

public interface queueView {
    public String getToken();
}
