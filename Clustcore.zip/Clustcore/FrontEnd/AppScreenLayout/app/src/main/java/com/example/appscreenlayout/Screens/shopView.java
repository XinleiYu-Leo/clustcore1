package com.example.appscreenlayout.Screens;

import android.text.Editable;

public interface shopView {

    public void afterTextChanged(Editable s);
    public int getBalance();
    public void resetBalance();

}
