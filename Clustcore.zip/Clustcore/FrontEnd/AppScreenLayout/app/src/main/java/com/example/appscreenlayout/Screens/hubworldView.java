package com.example.appscreenlayout.Screens;

public interface hubworldView {
    public void openActivity();
    public void openActivity1();
    public void openLevel();
    public String getUser();
    public String getToken();
}
