package com.example.appscreenlayout.app;

public interface Observer {
    public void update(String player);
}
