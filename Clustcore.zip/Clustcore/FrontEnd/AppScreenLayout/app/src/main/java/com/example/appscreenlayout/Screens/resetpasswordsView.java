package com.example.appscreenlayout.Screens;

public interface resetpasswordsView {
    public void back_Login();

}
