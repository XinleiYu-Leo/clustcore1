package com.example.appscreenlayout.Screens;

public interface mainactivityView {

    public void openLogin();
    public void openRegister();
}
