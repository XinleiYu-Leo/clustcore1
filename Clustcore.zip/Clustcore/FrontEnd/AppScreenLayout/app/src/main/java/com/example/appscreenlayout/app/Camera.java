package com.example.appscreenlayout.app;

/** Camera Object that will control map movement**/
public class Camera {
}
