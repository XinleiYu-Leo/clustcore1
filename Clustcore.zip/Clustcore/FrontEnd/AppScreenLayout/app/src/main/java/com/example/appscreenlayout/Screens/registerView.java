package com.example.appscreenlayout.Screens;

public interface registerView {
    public void pass_Confirm(String user, String password, String conPass, String email);
    public void Registration(String username, String password, String email);
    public void back_Main();

}
