package com.example.appscreenlayout.Screens;

public interface basiclevelView {
    /**
    basicLevel only contains protected and static methods
     */
}
