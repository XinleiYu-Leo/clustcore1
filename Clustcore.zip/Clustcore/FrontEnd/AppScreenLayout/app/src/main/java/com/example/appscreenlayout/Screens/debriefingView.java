package com.example.appscreenlayout.Screens;

public interface debriefingView {
    /**
     * debrefing only contains protected and private classes
     */
}
