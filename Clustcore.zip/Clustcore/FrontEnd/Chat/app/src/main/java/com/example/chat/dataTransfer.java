package com.example.chat;

public class dataTransfer {

    public static String title;
    public static int rating;
    public static int year;
    public static int time;
    private String url= "https://api.myjson.com/bins/j5f6b" ;

    public dataTransfer() {

    }

    public dataTransfer(String title, int rating, int year) {
        this.title = title;
        this.rating = rating;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getTime() {
        return time;
    }
    public void setTime(){
        this.time = time;
    }

    public String getURL() {
        return url;
    }
    
}
