
package com.example.chat;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button freshBalance;
    private int  balance = 250;
    private Editable stringBalance;
    private EditText yourEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yourEditText = (EditText) findViewById(R.id.currencyBalance);
        freshBalance= findViewById(R.id.refresh);
        freshBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                afterTextChanged(stringBalance);
            }
        }

        final Button secondActivityBtn = (Button) findViewById(R.id.button2);
        secondActivityBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent (getApplicationContext(), Chat.class);
                startActivity(startIntent);
            }
        });

    }
            public void afterTextChanged(Editable s) {
                yourEditText.setText("$" + balance+  yourEditText.getText().toString());
            }

}

